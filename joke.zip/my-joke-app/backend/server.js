/*const express = require('express');*/
import express from 'express';
const app = express();

// Simple CORS middleware - allows requests from the dev server (change as needed)
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});

app.get('/', (req, res) => {
  res.send('Hello World!');
});

//get 5 jokes
app.get('/api/jokes', (req, res) => {
  const jokes = [
    {
        id: 1,
        title:'joke',
        content:'Why did the scarecrow win an award? Because he was outstanding in his field!'
    },
    {
        id: 2,
        title:'joke',
        content:'Why don\'t scientists trust atoms? Because they make up everything!'
    },
    {
        id: 3,
        title:'joke',
        content:'Why did the bicycle fall over? Because it was two-tired!'  
    },
    {
        id: 4,
        title:'joke',
        content:'Why did the tomato turn red? Because it saw the salad dressing!'
    },
    {
        id: 5,
        title:'joke',
        content:'Why did the math book look sad? Because it had too many problems!'
    }
    ];
    res.send(jokes);
});
    
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});